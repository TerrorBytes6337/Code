package frc.SmartDashboardHelper;

public abstract class DashboardReadyData
{
    public abstract String toString();
    public abstract Object fromString(String objString);
}