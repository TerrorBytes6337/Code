// package frc.robot.commands;

// import edu.wpi.first.wpilibj.command.Command;
// import edu.wpi.first.wpilibj.smartdashboard.SmartDashboard;

// public class InitTestMode extends Command
// {
//     public InitTestMode()
//     {
        
//     }
//     private void smartDashboardInit()
//     {
//     }
// }