package frc.robot.reporter;

import frc.robot.Robot;

public class HardwarePerformance extends ReporterBase
{
    private Robot bot;
    public HardwarePerformance(final Robot bot)
    {
        this.bot = bot;
    }
    public void getData()
    {
        
    }
    public void reportData()
    {

    }
}