// package frc.robot.subsystems;

// import edu.wpi.first.wpilibj.command.Subsystem;
// public class NavigationSubsystem extends DebugSubsystem
// {
    
//     @Override
//     protected void initDefaultCommand() {

//     }

// }