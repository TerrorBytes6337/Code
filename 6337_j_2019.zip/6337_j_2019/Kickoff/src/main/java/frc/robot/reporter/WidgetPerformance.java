package frc.robot.reporter;

public class WidgetPerformance extends ReporterBase
{

    @Override
    public void getData() {

    }

    @Override
    public void reportData() {

    }

}