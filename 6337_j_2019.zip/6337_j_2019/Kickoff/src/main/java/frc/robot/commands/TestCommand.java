package frc.robot.commands;

import java.util.ArrayList;
import edu.wpi.first.wpilibj.command.Command;
public class TestCommand
{
    public static ArrayList<Command> allCommands = new ArrayList<Command>();
}