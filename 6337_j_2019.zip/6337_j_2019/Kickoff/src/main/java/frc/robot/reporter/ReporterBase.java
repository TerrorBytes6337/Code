package frc.robot.reporter;

public abstract class ReporterBase
{
    public abstract void getData();
    public abstract void reportData();
}